--[[
	Copyright (C) 2014 HarpyWar (harpywar@gmail.com)
	
	This file is a part of the PvPGN Project http://pvpgn.pro
	Licensed under the same terms as Lua itself.
]]--


attr_type_str,
attr_type_num,
attr_type_bool,
attr_type_raw
= 0,1,2,3